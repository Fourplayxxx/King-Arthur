# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: KingArthurTV
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.kingarthurtv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "8zTyEg6ywJ4" 	#AudioMachine- Guardians At The Gate
YOUTUBE_CHANNEL_ID_2 = "COz25ZFCsz0" 	#AudioMachine- Reaching
YOUTUBE_CHANNEL_ID_3 = "wVLUrF6baMc" 	#AudioMachine- Akkadian Empire
YOUTUBE_CHANNEL_ID_4 = "jB4vALqboUw" 	#AudioMachine- House Of Cards
YOUTUBE_CHANNEL_ID_5 = "7xPobvJqITg" 	#AudioMachine- 11 Days In Hell
YOUTUBE_CHANNEL_ID_6 = "lUxo3mopWCg" 	#AudioMachine- Eterna
YOUTUBE_CHANNEL_ID_7 = "0I6pPpO8hQA" 	#AudioMachine- Veni Vidi Vici
YOUTUBE_CHANNEL_ID_8 = "4OFgrADK5kk" 	#AudioMachine- Breath And Life
YOUTUBE_CHANNEL_ID_9 = "uUUPzjOmZR0" 	#AudioMachine- Creation
YOUTUBE_CHANNEL_ID_10 = "MESwXvkn6yE" 	#AudioMachine- Redemption
YOUTUBE_CHANNEL_ID_11 = "mG2xDKo_flI" 	#AudioMachine- Beyond Good And Evil
YOUTUBE_CHANNEL_ID_12 = "Kl4QYtnjjCs" 	#AudioMachine- Lost Empire
YOUTUBE_CHANNEL_ID_13 = "ne1HkK_2aG0" 	#AudioMachine- Sands Of Time
YOUTUBE_CHANNEL_ID_14 = "wbFt28Ri7ps" 	#AudioMachine- Black Cauldron
YOUTUBE_CHANNEL_ID_15 = "_ENhqsG35Ck" 	#AudioMachine- Lost Generation
YOUTUBE_CHANNEL_ID_16 = "y1P5SDuLjIk" 	#AudioMachine- Hell's Battalion
YOUTUBE_CHANNEL_ID_17 = "j-1bcLQ9X7k" 	#AudioMachine- Red Warrior
YOUTUBE_CHANNEL_ID_18 = "YHKIcSJoT2Y" 	#AudioMachine- Lachrimae
YOUTUBE_CHANNEL_ID_19 = "pLSioLjlsCA" 	#AudioMachine- Legions Of Doom
YOUTUBE_CHANNEL_ID_20 = "1LFaOOuKKrU" 	#AudioMachine- Road To Glory
YOUTUBE_CHANNEL_ID_21 = "9YSkBLCoQm4" 	#AudioMachine- Army Of Kings
YOUTUBE_CHANNEL_ID_22 = "159e3iP0k_A" 	#AudioMachine- Lost Raiders
YOUTUBE_CHANNEL_ID_23 = "9Fi8qEq86ok" 	#AudioMachine- Battle Of The Kings
YOUTUBE_CHANNEL_ID_24 = "fFFutgMnwVA" 	#AudioMachine- Path To Freedom
YOUTUBE_CHANNEL_ID_25 = "fBmW3pqz2Xw" 	#AudioMachine- Hymn Of The Rising
YOUTUBE_CHANNEL_ID_26 = "sTV0hJB3KBw" 	#AudioMachine- Danuvius
YOUTUBE_CHANNEL_ID_27 = "hB7qCRufCiM" 	#AudioMachine- Blood And Glory
YOUTUBE_CHANNEL_ID_28 = "DAhY2DzIT88" 	#AudioMachine- The Messenger

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Guardians At The Gate",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Reaching",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Akkadian Empire",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

 plugintools.add_item( 
        #action="", 
        title="AudioMachine- House Of Cards",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- 11 Days In Hell",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Eterna",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Veni Vidi Vici",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Breath And Life",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Creation",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )		
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Redemption",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Beyond Good And Evil",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Lost Empire",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Sands Of Time",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Black Cauldron",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Lost Generation",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Hell's Battalion",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Red Warrior",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Lachrimae",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Legions Of Doom",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Road To Glory",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Army Of Kings",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Lost Raiders",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Battle Of The Kings",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Path To Freedom",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- Hymn Of The Rising",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Danuvius",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AudioMachine- Blood And Glory",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
		 plugintools.add_item( 
        #action="", 
        title="AudioMachine- The Messenger",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="http://i1054.photobucket.com/albums/s200/fourplay4/kingarthur.png",
		fanart="http://img.youtube.com/vi/8zTyEg6ywJ4/maxresdefault.jpg",
        folder=True )
		
run()
